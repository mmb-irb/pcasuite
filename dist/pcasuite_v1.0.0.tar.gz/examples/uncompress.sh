#!/bin/sh

../pcaunzip -i 1b9p.pcz -o 1b9p.uncompressed.x

