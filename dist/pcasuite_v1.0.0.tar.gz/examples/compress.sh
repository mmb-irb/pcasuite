#!/bin/sh

../pcazip -i 1b9p.x -o 1b9p.pcz -p 1b9p.pdb -g

